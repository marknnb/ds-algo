@interface A
{
}