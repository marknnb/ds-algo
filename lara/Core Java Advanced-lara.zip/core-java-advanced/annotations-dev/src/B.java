@interface B
{
	void test();
}

/*
    1. any primitive data type
    2. any enum type
	3. String type
	4. Class type
	5. any annotation type
	6. arrays of above
*/