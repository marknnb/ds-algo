@interface C
{
	Integer test();
}

