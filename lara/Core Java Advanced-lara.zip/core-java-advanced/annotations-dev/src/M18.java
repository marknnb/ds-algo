import java.util.ArrayList;

@SuppressWarnings("unchecked")
class M18 
{
	public static void main(String[] args) 
	{
		ArrayList list = new ArrayList();
		list.add(90);
		list.add(90);
		list.add(90);
		System.out.println(list);
	}
}
