class M1 
{
	public static void main(String[] args) 
	{
		int i = 10;
		System.out.println("@step1: " + i);
		i = 20;
		System.out.println("@step2: " + i);
		i = 30;
		System.out.println("@step3: " + i);
	}
}
