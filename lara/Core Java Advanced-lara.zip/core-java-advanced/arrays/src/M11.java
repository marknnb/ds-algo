class M11
{
	public static void main(String[] args) 
	{
		int[] x;
		x[] = new int[2];
		System.out.println("--------");
		System.out.println(x[0] + ", " + x[1]);
		x[0] = 100;
		x[1] = 200;
		System.out.println(x[0] + ", " + x[1]);
	}
}
