class M13
{
	public static void main(String[] args) 
	{
		int[] x, y, z;
		x = new int[2];
		y = new int[20];
		z = new int[12];
		System.out.println("done");
	}
}
