class M14
{
	public static void main(String[] args) 
	{
		int[] x = new int[2], y, z = new int[12];
		y = new int[20];
		System.out.println("done");
	}
}
