class M15
{
	public static void main(String[] args) 
	{
		int x = 10, y[], z[] = new int[12], m = 20;
		y = new int[20];
		System.out.println("done");
	}
}
