class M16
{
	public static void main(String[] args) 
	{
		String s1 = "abc", s2[] = new String[4], s3 = "hello";
		System.out.println(s1 + ", " + s3 + ", " + s2[3]);
	}
}
