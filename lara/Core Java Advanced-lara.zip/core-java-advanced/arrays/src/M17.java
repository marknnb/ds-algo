class M17 
{
	public static void main(String[] args) 
	{
		int[]x = new int[10];
		System.out.println(x[4]);
	}
}
