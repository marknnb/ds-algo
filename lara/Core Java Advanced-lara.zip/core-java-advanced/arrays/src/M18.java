class M18
{
	public static void main(String[] args) 
	{
		int []x = new int[10];
		int y[] = new int[5];
		int[]z = new int[5];
		

		System.out.println("done");
	}
}
