class M2 
{
	public static void main(String[] args) 
	{
		int[] elements = new int[3];
		elements[0] = 10;
		elements[1] = 20;
		elements[2] = 30;
		System.out.println(elements[0] + ", " + elements[1] + ", " + elements[2]);
	}
}
