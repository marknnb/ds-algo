class M20 
{
	public static void main(String[] args) 
	{
		double[] elements = new double[10.0];
		System.out.println(elements[2.0]);
	}
}
