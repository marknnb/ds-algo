class M21
{
	public static void main(String[] args) 
	{
		byte b1 = 100;
		double[] elements = new double[b1];
		byte b2 = 50;
		System.out.println(elements[b2]);
	}
}
