class M22
{
	public static void main(String[] args) 
	{
		short b1 = 100;
		double[] elements = new double[b1];
		short b2 = 50;
		System.out.println(elements[b2]);
	}
}
