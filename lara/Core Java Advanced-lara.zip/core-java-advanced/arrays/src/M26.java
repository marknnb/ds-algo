import java.util.Arrays;
class M26
{
	public static void main(String[] args) 
	{
		int[] x = {10, 20, 30, 40};
		System.out.println(x.length);
		System.out.println(Arrays.toString(x));
	}
}
