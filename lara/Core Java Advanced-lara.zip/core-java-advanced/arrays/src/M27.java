import java.util.Arrays;
class M27
{
	public static void main(String[] args) 
	{
		String[] x = {

						"abc",
						"xyz",
						"hello",
						"test",
						"java",
					 };
		System.out.println(x.length);
		System.out.println(Arrays.toString(x));
	}
}
