class M7
{
	public static void main(String[] args) 
	{
		int[] x = new int[5];
		System.out.println(x[5]);
	}
}
