class M8
{
	public static void main(String[] args) 
	{
		int[] x = new int[5];
		System.out.println(x[-1]);
	}
}
