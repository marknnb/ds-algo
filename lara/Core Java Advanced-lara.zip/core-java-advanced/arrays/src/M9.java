class M9
{
	public static void main(String[] args) 
	{
		int[] x = new int[0];
		System.out.println("--------");
		System.out.println(x[0]);
	}
}
