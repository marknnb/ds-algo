package pack1;

public class J {
	public static void main(String[] args) 
	{
		System.out.println(1);
		//assert true : test();
		System.out.println(2);
	}
	static void test()
	{
		
	}
}
