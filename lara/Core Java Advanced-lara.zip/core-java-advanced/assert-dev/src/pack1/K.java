package pack1;

public class K {
	public static void main(String[] args) 
	{
		//int assert = 10;
		//System.out.println(assert);
	}
}
