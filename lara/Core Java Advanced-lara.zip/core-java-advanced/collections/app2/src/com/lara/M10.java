package com.lara;

import java.util.PriorityQueue;

public class M10 {
	public static void main(String[] args) {
		PriorityQueue queue = new PriorityQueue();
		queue.add(90);
		queue.add(190.0);
		queue.add(1190);
		queue.add(910);
		System.out.println(queue);
	}
}
