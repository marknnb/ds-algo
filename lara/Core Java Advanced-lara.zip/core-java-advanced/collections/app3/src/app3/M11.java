package app3;

import java.util.LinkedHashSet;

public class M11 {
	public static void main(String[] args) {
		LinkedHashSet set = new LinkedHashSet();
		set.add(90);
		set.add(90);
		set.add(190);
		set.add(190);
		set.add(90);
		set.add(190);
		set.add(290);
		set.add(390);
		set.add(390);
		set.add(290);
		set.add(390);
		set.add(500);
		System.out.println(set);
	}
}
