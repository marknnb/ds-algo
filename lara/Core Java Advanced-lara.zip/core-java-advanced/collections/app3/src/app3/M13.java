package app3;

import java.util.HashSet;
import java.util.TreeSet;

public class M13 {
	public static void main(String[] args) {
		TreeSet set = new TreeSet();
		set.add(90);
		set.add(190);
		set.add(910);
		set.add(901);
		set.add(290);
		set.add(920);
		set.add(500);
		System.out.println(set);
	}
}
