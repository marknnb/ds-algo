package app3;

import java.util.HashSet;

public class M2 {
	public static void main(String[] args) {
		HashSet set = new HashSet();
		set.add(90);
		set.add(90);
		set.add(90);
		set.add(90);
		set.add(90);
		set.add(90);
		System.out.println(set);
	}
}
