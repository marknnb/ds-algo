package com.lara1;

public class M2 {
	public static void main(String[] args) {
		int i = 10 / 0;
		int j = Integer.parseInt("xyz");
		int[] elements = new int[999999999];
		Object obj = new Object();
		Integer obj1 = (Integer) obj;
		int[] x = new int[4];
		int k = x[5];
	}
}
