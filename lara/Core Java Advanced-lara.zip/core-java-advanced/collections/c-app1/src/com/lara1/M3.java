package com.lara1;

import java.io.FileWriter;
import java.sql.DriverManager;
import java.text.DateFormat;

public class M3 {
	public static void main(String[] args) {
		//Class.forName("");
		//DriverManager.getConnection("");
		DateFormat df = null;
		//df.parse("");
		//Thread.sleep(90900);
		//FileWriter f1 = new FileWriter("");
		M3 obj = new M3();
		//obj.clone();
		
		
		
		
	}
}
