package com.lara1;

public class M4 {
	public static void main(String[] args) throws ClassNotFoundException 
	{
		Class.forName("");
	}
}
