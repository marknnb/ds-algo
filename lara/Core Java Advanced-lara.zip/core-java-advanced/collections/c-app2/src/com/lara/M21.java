package com.lara;

import java.util.Vector;

public class M21 {
	public static void main(String[] args) {
		Vector v1 = new Vector();
		v1.add(9000);
		v1.add(100);
		v1.add(90000);
		v1.add(9000);
		v1.add(0);
		System.out.println(v1);
	}
}
