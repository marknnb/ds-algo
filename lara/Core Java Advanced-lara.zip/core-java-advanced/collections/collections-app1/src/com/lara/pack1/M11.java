package com.lara.pack1;

import java.util.LinkedHashMap;

public class M11 {
	public static void main(String[] args) {
		LinkedHashMap map = new LinkedHashMap();
		map.put("abc", 34);
		map.put("abc1", 14);
		map.put("abc2", 31);
		map.put("abc3", 32);
		map.put("abc4", 24);
		map.put("abc5", 37);
		System.out.println(map);
	}
}
