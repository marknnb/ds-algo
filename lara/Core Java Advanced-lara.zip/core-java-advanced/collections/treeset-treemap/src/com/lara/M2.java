package com.lara;

import java.util.TreeSet;

public class M2 {
	public static void main(String[] args) {
		TreeSet<Integer> set = new TreeSet<Integer>();
		set.add(100);
		set.add(10);
		set.add(null);
		set.add(90);
		System.out.println(set);
	}
}
