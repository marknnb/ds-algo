enum B
{
}

class C
{
}

interface D
{
}

@interface E
{
}


