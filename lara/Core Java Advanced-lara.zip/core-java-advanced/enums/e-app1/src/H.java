enum G
{
	CON1, CON2, CON3, CON4
}
class H 
{
	public static void main(String[] args) 
	{
		G g1 = G.CON1;
		G g2 = G.CON4;
		System.out.println(g1);
		System.out.println(g2);
	}
}
