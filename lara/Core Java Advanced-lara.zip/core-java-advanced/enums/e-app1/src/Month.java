enum Month 
{
	JAN, FEB, MAR, APR, MAY, JUN, JUL, 
	AUG, SPT, OCT, NOV, DEC;
}