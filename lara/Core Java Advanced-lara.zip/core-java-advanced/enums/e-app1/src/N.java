class N 
{
	public static void main(String[] args) 
	{
		Month all[] = Month.values();

		for(int i = 0; i < all.length; i++)
		{
			System.out.println(all[i]);
		}
	}
}
