enum Day
{
	MON, TUE, WED, THR, FRI, SAT, SUN;
}

class T 
{
	public static void main(String[] args) 
	{
		Day d1 = Day.SAT;
		System.out.println(d1);
		Day d2 = Day.SUN;
		System.out.println(d2);
	}
}
