class U 
{
	public static void main(String[] args) 
	{
		Month m1 = Month.JUL;
		System.out.println(m1);
		Month m2 = Month.JAN;
		System.out.println(m2);
	}
}
