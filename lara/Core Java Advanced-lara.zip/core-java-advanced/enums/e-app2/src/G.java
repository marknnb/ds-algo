enum G
{
	void test()
	{
	}
}