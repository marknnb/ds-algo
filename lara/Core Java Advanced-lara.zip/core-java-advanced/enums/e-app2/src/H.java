enum H
{
	;
	void test()
	{
	}
}