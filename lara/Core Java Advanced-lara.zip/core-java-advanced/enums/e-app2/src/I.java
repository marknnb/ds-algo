enum I
{
	c1, c2, c3;
	private I()
	{
	}	
}