enum J
{
	c1, c2, c3;
	J()
	{
	}	
}