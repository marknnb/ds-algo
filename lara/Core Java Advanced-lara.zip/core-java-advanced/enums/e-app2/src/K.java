enum K
{
	c1, c2, c3;
	protected K()
	{
	}	
}