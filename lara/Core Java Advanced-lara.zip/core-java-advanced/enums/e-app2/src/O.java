class N
{

}
enum O extends N 
{
}
//every enum is extending with java.lang.Enum