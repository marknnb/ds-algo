interface P
{
	void test1();
}
enum Q implements P 
{
	;
	public void test1()
	{
	}
}
