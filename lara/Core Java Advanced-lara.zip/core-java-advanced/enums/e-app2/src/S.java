interface R
{
	void test1();
}
abstract enum S implements R
{
}