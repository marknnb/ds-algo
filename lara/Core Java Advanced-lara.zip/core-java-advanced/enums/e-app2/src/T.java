interface Inter
{
	void test1();
}
abstract enum T implements Inter
{
	;
}