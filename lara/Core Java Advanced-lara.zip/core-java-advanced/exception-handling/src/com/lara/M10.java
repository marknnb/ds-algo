package com.lara;

public class M10 {
	public static void main(String[] args) {
		System.out.println("main begin");
		main(null);
		System.out.println("main end");
	}
}
