package com.lara;

public class M11 {
	public static void main(String[] args) {
		System.out.println("main begin");
		main(args);
		System.out.println("main end");
	}
}
