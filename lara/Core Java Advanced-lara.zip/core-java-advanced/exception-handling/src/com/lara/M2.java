package com.lara;

public class M2 {
	public static void main(String[] args) {
		System.out.println("main begin");
		int i = Integer.parseInt("90R");
		System.out.println("main end");
	}
}
