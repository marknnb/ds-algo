package com.lara;

public class M29 {
	public static void main(String[] args) {
		try
		{
			
		}
		catch(NumberFormatException ex)
		{
			
		}
		
		try
		{
			
		}
		//int i = 10;
		catch(NumberFormatException ex)
		{
			
		}
	}
}
