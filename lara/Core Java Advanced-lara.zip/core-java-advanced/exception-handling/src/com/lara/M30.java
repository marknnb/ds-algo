package com.lara;

public class M30 {
	public static void main(String[] args) {
		try
		{
			
		}
		catch(ArrayIndexOutOfBoundsException ex)
		{
			
		}
		//System.out.println("done");
		catch(NullPointerException ex)
		{
			
		}
	}
}
