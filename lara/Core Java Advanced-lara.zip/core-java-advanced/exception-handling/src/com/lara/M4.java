package com.lara;

public class M4 {
	public static void main(String[] args) {
		System.out.println("main begin");
		int[] elements = new int[5];
		int i = elements[10];
		System.out.println("main end");
	}
}
