package com.lara;

public class M5 {
	public static void main(String[] args) {
		System.out.println("main begin");
		Object obj = new Object();
		String s1 = (String) obj;
		System.out.println("main end");
	}
}
