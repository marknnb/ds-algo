package com.lara;

public class M8 {
	public static void main(String[] args) {
		System.out.println("main begin");
		String s1 = "hello";
		//           01234
		String s2 = s1.substring(2, 10);
		System.out.println("main end");
	}
}
