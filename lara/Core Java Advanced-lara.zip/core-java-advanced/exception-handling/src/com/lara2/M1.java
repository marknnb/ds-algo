package com.lara2;

public class M1 {
	public static void main(String[] args) {
		System.out.println("main begin");
		//int i = 10 / 0;
		System.out.println("-------");
		//int j = Integer.parseInt("xyz");
		System.out.println("---------");
		String s1 = null;
		//int k = s1.length();
		System.out.println("---------");
		Object obj1 = new Integer(40);
		//String obj2 = (String) obj1;
		System.out.println("main end");
	}
}
