package com.lara2;

public class M2 {
	public static void main(String[] args) {
		System.out.println("main begin");
		//main(null);
		System.out.println("-------");
		int[] elements = new int[999999999];
		System.out.println("-------");
		System.out.println("main end");
	}
}
