package com.lara3;

public class M3 {
	void test()
	{
		//clone();
		
		
		try
		{
			clone();
		}
		catch(CloneNotSupportedException ex)
		{
			
		}
	}
}
