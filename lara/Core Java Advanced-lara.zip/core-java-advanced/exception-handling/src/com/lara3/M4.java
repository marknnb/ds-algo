package com.lara3;

import java.io.FileReader;
import java.io.IOException;

public class M4 {
	public static void main(String[] args) {
		
		
		//FileReader f1 = new FileReader("");
		
		
		try
		{
			FileReader f2 = new FileReader("");						
		}
		catch(IOException ex)
		{
			
		}
	}
}
