package com.lara3;

import java.sql.DriverManager;
import java.sql.SQLException;

public class M5 {
	public static void main(String[] args) {
		
		//DriverManager.getConnection("");		
		
		try
		{
			DriverManager.getConnection("");
		}
		catch(SQLException ex)
		{
			
		}
	}
}
