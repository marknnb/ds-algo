package com.lara3;

public class M6 {
	public static void main(String[] args) {
		
		
		//Thread.sleep(10000);
		
		
		try
		{
			Thread.sleep(10000);
		}
		catch(InterruptedException ex)
		{
			
		}
	}
}
