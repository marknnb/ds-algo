package com.lara3;

import java.text.ParseException;
import java.text.SimpleDateFormat;

public class M7 {
	public static void main(String[] args) {
		SimpleDateFormat sd = null;
		
		//sd.parse("");
		
		
		try
		{
			sd.parse("");
		}
		catch(ParseException ex)
		{
			
		}
		
	}
}
