package com.lara4;

public class M1 {
	public static void main(String[] args) throws ClassNotFoundException{
		Class.forName("");
	}
}
