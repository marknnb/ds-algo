package com.lara4;

public class M14 {
	public static void main(String[] args) {
		try
		{
			System.out.println("done");
			int i = 10;
			i++;
			i += 2000;
		}
		catch(ClassNotFoundException ex)
		{
			
		}
	}
}
