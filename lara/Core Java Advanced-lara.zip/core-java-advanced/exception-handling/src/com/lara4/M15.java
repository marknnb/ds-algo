package com.lara4;

public class M15 {
	public static void main(String[] args) {
		try
		{
			System.out.println("done");
			int i = 10;
			i++;
			i += 2000;
			Class.forName("");
			Class.forName("");
			Class.forName("");
		}
		catch(ClassNotFoundException ex)
		{
			
		}
	}
}
