package com.lara4;

public class M16 {
	public static void main(String[] args) {
		try
		{
			
		}
		catch(NullPointerException ex)
		{
			
		}
		
		try
		{
			
		}
		catch(InterruptedException ex)
		{
			
		}
		
		try
		{
			
		}
		catch(Exception ex)
		{
			
		}
		
		try
		{
			
		}
		catch(Throwable t)
		{
			
		}
	}
}
