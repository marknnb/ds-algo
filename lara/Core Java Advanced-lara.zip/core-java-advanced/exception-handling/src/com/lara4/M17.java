package com.lara4;

public class M17 {
	public static void main(String[] args) {
		test1();
		test2();
		test3();
		test4();
	}
	static void test1() throws ClassNotFoundException
	{
		
	}
	static void test2() throws ArithmeticException
	{
		
	}	
	static void test3() throws Exception
	{
		
	}	
	static void test4() throws Throwable
	{
		
	}	
}
