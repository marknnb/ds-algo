package com.lara4;
class A{
	A() throws ClassNotFoundException
	{
		
	}
}
public class M18 {
	public static void main(String[] args) throws ClassNotFoundException{
		A a1 = new A();
	}
}
