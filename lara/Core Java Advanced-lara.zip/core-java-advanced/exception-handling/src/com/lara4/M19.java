package com.lara4;

class B
{
	B() throws InterruptedException 
	{
		
	}
}
class C extends B
{
	C() throws InterruptedException
	{
	}
}
public class M19 {

}
