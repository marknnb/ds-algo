package com.lara4;

public class M3 {
	public static void main(String[] args)  throws ClassNotFoundException{
		test();
	}
	static void test() throws ClassNotFoundException
	{
		Class.forName("");
	}
}
