package com.lara5;

import java.io.IOException;

public class A {
	void test1()
	{
		
	}
	void test2() throws NullPointerException
	{
		
	}
	void test3() throws ClassNotFoundException
	{
		
	}
	void test4() throws IOException
	{
		
	}
	void test5() throws Exception
	{
		
	}

	void test6() throws Throwable
	{
		
	}

}


















