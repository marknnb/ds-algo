import java.io.*;
class A implements Serializable
{
	int i;
	double j;
	double k;
	//private static final long serialVersionUID = 9909L;
}




/*
	private static final long serialVersionUID = 668318327513677947L;
	private static final long serialVersionUID = 3581752467090598360L;

*/