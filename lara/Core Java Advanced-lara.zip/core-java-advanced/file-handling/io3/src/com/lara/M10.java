package com.lara;

import java.io.Console;

public class M10 {
	public static void main(String[] args) {
		Console c1 = System.console();
		System.out.println(c1);
	}
}
