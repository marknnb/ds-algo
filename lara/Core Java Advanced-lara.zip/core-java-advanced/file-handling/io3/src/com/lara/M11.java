package com.lara;

import java.io.PrintStream;

public class M11 {
	public static void main(String[] args) {
		PrintStream p1 = System.out;
		p1.println("done");
		p1.println("done");
		p1.println("done");
		p1.println("done");
		p1.println("done");
	}
}
