class A
{
	A(String s1)
	{
	}
}
class M10 
{
	public static void main(String[] args) 
	{
		A a1 = new A("abc");
		A a2 = new A("xyz");
		A a3 = new A("hello");
		System.out.println("done");
	}
}
