class A < T >
{
	T var;
}
class M55 
{
	public static void main(String[] args) 
	{
		A<int> a1 = new A<int>();
		System.out.println("done");
	}
}
