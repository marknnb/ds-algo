class A < T >
{
	static T obj;
	static void test(T arg)
	{
	}
}
class M56 
{
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}
