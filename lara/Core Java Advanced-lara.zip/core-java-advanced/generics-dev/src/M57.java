interface A < T >
{
	T obj;
}
class M57
{
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}
