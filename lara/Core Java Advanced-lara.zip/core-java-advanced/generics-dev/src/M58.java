class A < T >
{
	T obj;
}
class M58
{
	public static void main(String[] args) 
	{
		A<Integer> a1 = new A<Integer>();
		a1.obj = 1000;
		System.out.println("done");
	}
}
