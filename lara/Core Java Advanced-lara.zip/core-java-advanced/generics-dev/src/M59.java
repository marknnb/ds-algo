class A < T >
{
	T obj;
}
class M59
{
	public static void main(String[] args) 
	{
		A<Integer> a1 = new A<String>();
		System.out.println("done");
	}
}
