class Q extends P
{
}