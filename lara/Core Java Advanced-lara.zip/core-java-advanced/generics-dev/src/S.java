class S extends R
{
}