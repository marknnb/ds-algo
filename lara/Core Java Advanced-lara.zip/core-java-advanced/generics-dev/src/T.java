class T extends S
{
}