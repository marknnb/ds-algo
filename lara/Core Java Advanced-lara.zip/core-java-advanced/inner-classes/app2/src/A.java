class A 
{
	class B
	{
	}
	static class C
	{
	}
	public static void main(String[] args) 
	{
		A a1 = null;
		B b1 = null;
		C c1 = null;
		System.out.println("done");
	}
}
