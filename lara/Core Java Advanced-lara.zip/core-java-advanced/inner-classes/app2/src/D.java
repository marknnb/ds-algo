class D 
{
	class B
	{
	}
	static class C
	{
	}
	public static void main(String[] args) 
	{
		B b1 = new B();
		C c1 = new C();
		System.out.println("done");
	}
}
