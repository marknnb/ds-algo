class L
{
	public static void main(String[] args) 
	{
		void test()
		{
			System.out.println("from A");
			System.out.println("from A");
			System.out.println("from A");
			System.out.println("from A");
		}
		test();
		test();
		test();
		System.out.println("done");
	}
}
