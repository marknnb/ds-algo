class N 
{
	N()
	{
		class A
		{
		}
	}
	
	{
		class A
		{
		}
	}
	public static void main(String[] args) 
	{
		class A
		{
		}
		System.out.println("done");
	}
}
