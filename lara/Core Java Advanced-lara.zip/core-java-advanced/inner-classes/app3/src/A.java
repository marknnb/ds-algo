class A 
{
	void test1()
	{
		System.out.println("from A.test1");
	}
	void test2()
	{
		System.out.println("from A.test2");
	}
}
