class I 
{
	public static void main(String[] args) 
	{
		System.out.println(1000);
		System.out.println(133.7888);
		System.out.println('t');
		System.out.println(false);
		System.out.println("xyz");
	}
}
