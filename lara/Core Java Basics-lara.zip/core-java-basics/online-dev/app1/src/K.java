class K 
{
	public static void main(String[] args) 
	{
		System.out.print(9);
		System.out.print(8);
		System.out.print(7);
		System.out.print(6);
		System.out.print(5);
	}
}
