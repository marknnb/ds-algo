class N 
{
	public static void main(String[] args) 
	{
		System.out.print("hello");
		System.out.print("hello");
		System.out.print("hello");
		System.out.print("hello");
		System.out.print("hello");
		System.out.print("hello");
	}
}
