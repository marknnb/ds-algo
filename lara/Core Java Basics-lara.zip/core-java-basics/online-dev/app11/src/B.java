class B
{
	public static void main(String[] args) 
	{
		int i;
		if(false)
		{
			i = 10;
		}
		else
		{
			i = 20;
		}
		System.out.println(i);
	}
}
