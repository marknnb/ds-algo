class D
{
	public static void main(String[] args) 
	{
		int i = false ? 10 : 20;
		System.out.println(i);
	}
}
