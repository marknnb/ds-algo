class E
{
	public static void main(String[] args) 
	{
		int k = 200;
		int i = k < 100 ? 10 : 20;
		System.out.println(i);
	}
}
