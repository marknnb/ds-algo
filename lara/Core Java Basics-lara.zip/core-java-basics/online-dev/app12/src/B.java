class B
{
	public static void main(String[] args) 
	{
		String s1 = "";
		String s2 = "abcgsggdhhjfdkkfkgfkkkfkkfgkfkkgfkkkgkkgkgkgkksadfaswer";
		System.out.println(s1.hashCode());
		System.out.println(s2.hashCode());
		System.out.println("int min:" + Integer.MIN_VALUE);
		System.out.println("int max:" + Integer.MAX_VALUE);
	}
}
