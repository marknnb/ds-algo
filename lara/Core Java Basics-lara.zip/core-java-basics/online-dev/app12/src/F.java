class F
{
	public static void main(String[] args) 
	{
		System.out.println("main begin");
		int i = 1;
		switch ( i )
		{
			case 1 : 
				System.out.println("from case1");
				System.out.println("from case1");

			case 5 : 
				System.out.println("from case5");
				System.out.println("from case5");

			case 10 : 
				System.out.println("from case10");
				System.out.println("from case10");
		}		
		System.out.println("main end");
	}
}
