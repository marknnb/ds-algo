class O
{
	public static void main(String[] args) 
	{
		System.out.println("main begin");
		switch ( 5 )
		{
			case 1 : 
				System.out.println("from case1");
				System.out.println("from case1");
				System.out.println("from case1");
				System.out.println("from case1");
				break;
			case 5 : 
				System.out.println("from case5");
				System.out.println("from case5");
				break;
		}		
		System.out.println("main end");
	}
}
