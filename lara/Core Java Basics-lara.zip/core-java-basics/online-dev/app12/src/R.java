class R
{
	public static void main(String[] args) 
	{
		System.out.println("main begin");
		byte i = 100;
		switch ( i )
		{
			case 10 : 
				System.out.println("from case10");
				break;
			case 50 : 
				System.out.println("from case50");
				break;
			case 70 : 
				System.out.println("from case70");
				break;
			case 100 : 
				System.out.println("from case100");
				break;
		}		
		System.out.println("main end");
	}
}
