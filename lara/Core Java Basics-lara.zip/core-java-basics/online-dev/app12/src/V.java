class V
{
	public static void main(String[] args) 
	{
		System.out.println("main begin");
		char c1 = 'a';
		switch ( c1 )
		{
			case 'a' : 
				System.out.println("from case a");
				break;
			case 't' : 
				System.out.println("from case t");
				break;
			case 'b' : 
				System.out.println("from case b");
				break;
		}		
		System.out.println("main end");
	}
}
