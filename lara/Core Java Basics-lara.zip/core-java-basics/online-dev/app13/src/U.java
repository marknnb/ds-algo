class U
{
	public static void main(String[] args) 
	{
		System.out.println("main begin");
		int i = 1;
		for( ; ; )
		{
			System.out.println("loop body:" +  i);
			i++;
		}
	}
}
