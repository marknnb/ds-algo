class R
{
	public static void main(String[] args) 
	{
		System.out.println("main begin");
		double[] elements = {1.2, 4.5, 7.0};
		for(int element : elements)    
		{
			System.out.println(element);
		}
		System.out.println("main end");
	}
}
