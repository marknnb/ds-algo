class H
{
	public static void main(String[] args) 
	{
		System.out.println("main");
	}
	public static void test()
	{
		System.out.println("test" );
	}

	System.out.println("end" );
}


