class L 
{
	public static void main(String[] args) 
	{
		System.out.println("main");
		return;
	}
}
