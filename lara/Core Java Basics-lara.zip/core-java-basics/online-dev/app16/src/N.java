class N
{
	public static void main(String[] args) 
	{
		System.out.println("main begin");
		return;
		System.out.println("main end");
	}
}
