class O
{
	public static void main(String[] args) 
	{
		System.out.println("main begin");
		if(true)
		{
			System.out.println("if block");	
			return;
		}
		System.out.println("main end");
	}
}
