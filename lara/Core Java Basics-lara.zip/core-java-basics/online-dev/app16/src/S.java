class S 
{
	public void static main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}
