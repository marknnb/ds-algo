class T 
{
	public static void main(String[] args) 
	{
		System.out.println("from main");
	}
	public static int test()
	{
		System.out.println("from test");
	}
}

/*
	primitive datatypes
	-------------------
	1. byte
	2. short
	3. int
	4. long
	5. float
	6. double
	7. char
	8. boolean

*/