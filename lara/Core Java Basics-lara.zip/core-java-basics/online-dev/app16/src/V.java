class V
{
	public static void main(String[] args) 
	{
		System.out.println("from main");
	}
	public static int test()
	{
		System.out.println("from test");
		return false;
	}
}