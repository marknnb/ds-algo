class A 
{
	static int i;  // field (or)  attribute  (or)  property

	public static void main(String[] args) 
	{
		System.out.println(i);
	}
}
