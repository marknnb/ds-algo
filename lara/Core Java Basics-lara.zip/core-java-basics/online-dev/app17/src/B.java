class B 
{
	static byte i;  
	static short j;  
	static int k;  
	static long m;  

	public static void main(String[] args) 
	{
		System.out.println(i);
		System.out.println(j);
		System.out.println(k);
		System.out.println(m);
	}
}
