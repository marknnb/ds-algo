class E
{
	static char i;  

	public static void main(String[] args) 
	{
		System.out.println(i);    //      '\u0000'
	}
}
