class F
{
	static String i;  
	static int[] j;
	static String[] k;

	public static void main(String[] args) 
	{
		System.out.println(i);
		System.out.println(j);
		System.out.println(k);
	}
}
