class G 
{
	static int i;
	static int j;
	static int k;
	public static void main(String[] args) 
	{
		System.out.println(i + ", " + j + "," + k);
	}
}
