class H
{
	static int i, j, k;
	public static void main(String[] args) 
	{
		System.out.println(i + ", " + j + "," + k);
	}
}
