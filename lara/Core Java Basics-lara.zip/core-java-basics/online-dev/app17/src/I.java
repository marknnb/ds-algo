class I
{
	static int m;
	static double m;
	public static void main(String[] args) 
	{
		System.out.println("done");
	}
}
