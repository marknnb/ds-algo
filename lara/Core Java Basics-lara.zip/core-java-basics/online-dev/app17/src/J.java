class J 
{
	public static void main(String[] args) 
	{
		int m = 10;
		double m = 4.5;
		System.out.println("done");
	}
}
