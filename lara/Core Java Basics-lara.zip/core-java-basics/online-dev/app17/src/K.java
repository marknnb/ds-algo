class K
{
	static int m;
	public static void main(String[] args) 
	{
		int m = 4;
		System.out.println(m);
	}
}
