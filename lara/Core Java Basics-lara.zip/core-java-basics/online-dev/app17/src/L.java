class L
{
	static int m;
	public static void main(String[] args) 
	{
		boolean m = true;
		System.out.println(m);
	}
}
