class M
{
	static int i;
	public static void main(String[] args) 
	{
		boolean i = true;
		System.out.println(i);
		System.out.println(M.i);
	}
}
