class O
{
	static int i;
	static double j;
	public static void main(String[] args) 
	{
		System.out.println(O.i);
		System.out.println(O.j);
	}
}
