class P
{
	public static void main(String[] args) 
	{
		static int i;
		System.out.println("done");
	}
}
