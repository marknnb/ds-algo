class Q 
{
	static int i = 10;
	static int j = 20;
	static int k;
	static int m = 30;
	public static void main(String[] args) 
	{
		System.out.println(i + ", " + j + ", " + k + ", " + m);
	}
}
