class S
{
	static int i = 10, j = 20, k, m = 30;
	public static void main(String[] args) 
	{
		System.out.println(i + ", " + j + ", " + k + ", " + m);
		i = 50;
		j = 510;
		k = 40;
		m = 140;
		System.out.println(i + ", " + j + ", " + k + ", " + m);
	}
}
