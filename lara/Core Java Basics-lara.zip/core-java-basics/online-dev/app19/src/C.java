class C
{
	static int i;
	static int j = i; //direct read


	public static void main(String[] args) 
	{
		System.out.println("done");
	}
}
