class G 
{
	static int i = G.j;
	static int j;
	public static void main(String[] args) 
	{
		System.out.println("done");
	}
}
