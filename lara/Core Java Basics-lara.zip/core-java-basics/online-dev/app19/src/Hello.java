class X 
{
	public static void test()
	{
		System.out.println("X.test()");
	}
}
