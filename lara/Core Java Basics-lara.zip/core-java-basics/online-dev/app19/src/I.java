class I 
{
	static
	{
		System.out.println(i);
	}

	static int i;

	public static void main(String[] args) 
	{
		System.out.println("done");
	}
}
