class M
{
	static int i = 20;

	static 
	{
		i = 100;
	}

	public static void main(String[] args) 
	{
		System.out.println(i);
	}
}
