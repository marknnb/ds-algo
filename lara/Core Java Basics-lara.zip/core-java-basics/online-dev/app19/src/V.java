class V 
{
	public static void main(String[] args) 
	{
		System.out.println("main from V");
	}
	static
	{
		System.out.println("SIB from V");
	}
}
