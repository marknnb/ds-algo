class Y 
{
	public static void main(String[] args) 
	{
		System.out.println("main begin");
		X.test();
		System.out.println("main end");
	}
}
