class A 
{
	public static void main(String[] args) 
	{
		int i = 10;
		System.out.println(i);
	}
}
