class C 
{
	public static void main(String[] args) 
	{
		int i = 10;
		System.out.println(i);
		i = 20;
		System.out.println(i);
		i = 2;
		System.out.println(i);
		i = 4;
		System.out.println(i);
	}
}
