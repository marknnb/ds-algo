class D 
{
	public static void main(String[] args) 
	{
		int i;
		i = 50;
		System.out.println(i);
		i = 40;
		System.out.println(i);
		i = 10;
		System.out.println(i);
	}
}
