class E 
{
	public static void main(String[] args) 
	{
		boolean b1 = true;
		System.out.println(b1);
		b1 = false;
		System.out.println(b1);
		b1 = true;
		b1 = false;
		b1 = true;
		System.out.println(b1);
	}
}
