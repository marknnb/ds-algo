class F 
{
	public static void main(String[] args) 
	{
		double var = 4.5;
		System.out.println(var);
		var = -4.9;
		System.out.println(var);
		var = 54.9;
		System.out.println(var);
		var = -0.9;
		System.out.println(var);
	}
}
