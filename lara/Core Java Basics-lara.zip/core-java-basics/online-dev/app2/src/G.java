class G 
{
	public static void main(String[] args) 
	{
		char c1 = 'r';
		System.out.println(c1);
		c1 = 'a';
		System.out.println(c1);
		c1 = '6';
		System.out.println(c1);
		c1 = '&';
		System.out.println(c1);
	}
}
