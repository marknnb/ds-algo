class H 
{
	public static void main(String[] args) 
	{
		char var;
		var = 'R';
		System.out.println(var);
		var = 'e';
		System.out.println(var);
		var = '7';
		System.out.println(var);
	}
}
