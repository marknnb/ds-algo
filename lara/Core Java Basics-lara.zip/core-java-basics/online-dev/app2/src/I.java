class I 
{
	public static void main(String[] args) 
	{
		String str = "hello";
		System.out.println(str);
		str = "India";
		System.out.println(str);
	}
}
