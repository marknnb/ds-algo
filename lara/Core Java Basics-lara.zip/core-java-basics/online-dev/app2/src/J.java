class J 
{
	public static void main(String[] args) 
	{
		int a = 10;
		int b = 90;
		System.out.println(a);
		System.out.println(b);
		a = 1000;
		b = 50;
		System.out.println(a);
		System.out.println(b);
	}
}
