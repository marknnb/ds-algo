class K 
{
	public static void main(String[] args) 
	{
		double d1 = 1.5;
		double d2 = 2.5;
		System.out.println(d1);
		System.out.println(d2);
		d1 = 4.5;
		System.out.println(d1);
		System.out.println(d2);
		d2 = 5.5;
		System.out.println(d1);
		System.out.println(d2);
	}
}
