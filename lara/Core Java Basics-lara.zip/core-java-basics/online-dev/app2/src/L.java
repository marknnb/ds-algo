class L 
{
	public static void main(String[] args) 
	{
		int i = 10;
		double j = 4.5;
		char k = 'y';
		System.out.println(i);
		System.out.println(j);
		System.out.println(k);
	}
}
