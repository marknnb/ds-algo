class M 
{
	public static void main(String[] args) 
	{
		int i = 10;
		int j = 20;
		int m = 10, n = 20;
		System.out.println(i);
		System.out.println(j);
		System.out.println(m);
		System.out.println(n);
	}
}
