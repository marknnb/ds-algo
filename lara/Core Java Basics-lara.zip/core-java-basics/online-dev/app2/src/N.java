class N 
{
	public static void main(String[] args) 
	{
		int i = 1, j = 3, k = 60;
		System.out.println(i);
		System.out.println(j);
		System.out.println(k);
	}
}
