class O 
{
	public static void main(String[] args) 
	{
		double d1 = 1.5, d2 = 5.5, d3 = 10.6;
		int i = 10, j = 20, k = 30;
		System.out.println(d1);
		System.out.println(d2);
		System.out.println(d3);
		System.out.println(i);
		System.out.println(j);
		System.out.println(k);
	}
}
