class P 
{
	public static void main(String[] args) 
	{
		int i, j = 1, k;
		i = 10;
		k = 40;
		System.out.println(i);
		System.out.println(j);
		System.out.println(k);
	}
}
