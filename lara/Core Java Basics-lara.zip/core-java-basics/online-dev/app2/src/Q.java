class Q 
{
	public static void main(String[] args) 
	{
		char c1, c2, c3;
		c1 = 'y';
		c2 = 't';
		c3 = 'R';
		System.out.println(c1);
		System.out.println(c2);
		System.out.println(c3);
	}
}
