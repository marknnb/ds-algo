class R 
{
	public static void main(String[] args) 
	{
		int i = 10, j = 10, k = 10, m = 10;
		System.out.println(i);
		System.out.println(j);
		System.out.println(k);
		System.out.println(m);
	}
}
