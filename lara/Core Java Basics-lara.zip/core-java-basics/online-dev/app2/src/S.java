class S 
{
	public static void main(String[] args) 
	{
		int i, j, k, m;
		i = j = k = m = 10;
		System.out.println(i);
		System.out.println(j);
		System.out.println(k);
		System.out.println(m);
	}
}
