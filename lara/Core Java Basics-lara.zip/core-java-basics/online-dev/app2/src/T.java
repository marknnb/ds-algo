class T 
{
	public static void main(String[] args) 
	{
		int i = 10;
		int j = 20;
		System.out.println(i);
		System.out.println(j);
		i = j = 40;
		System.out.println(i);
		System.out.println(j);
	}
}
