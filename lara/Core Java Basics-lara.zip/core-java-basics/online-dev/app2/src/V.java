class V 
{
	public static void main(String[] args) 
	{
		int age = 25;
		System.out.println(age);
		System.out.println("age is :" + age);
		System.out.println("age = " + age);
		System.out.println("age : " + age);
		System.out.println("age value is : " + age);
	}
}
