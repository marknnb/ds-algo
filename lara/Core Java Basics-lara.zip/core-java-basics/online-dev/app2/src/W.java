class W 
{
	public static void main(String[] args) 
	{
		double weight = 67.5;
		System.out.println(weight);
		System.out.println(weight + " is weight value");
		System.out.println(weight + " ==> weight value");
		System.out.println(weight + " --> weight value");
	}
}
