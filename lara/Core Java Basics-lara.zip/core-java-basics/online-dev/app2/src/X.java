class X 
{
	public static void main(String[] args) 
	{
		int i = 10, j = 20;
		System.out.println(i + ", ");
		System.out.println(i + ", " + j);
	}
}
