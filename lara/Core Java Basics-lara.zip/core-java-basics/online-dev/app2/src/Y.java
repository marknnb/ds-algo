class Y 
{
	public static void main(String[] args) 
	{
		int i = 10, j = 20;
		System.out.println("i = " + i);
		System.out.println("i = " + i + ", ");
		System.out.println("i = " + i + ", j = ");
		System.out.println("i = " + i + ", j = " + j);
	}
}
