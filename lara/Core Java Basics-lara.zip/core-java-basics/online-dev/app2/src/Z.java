class Z 
{
	public static void main(String[] args) 
	{
		int i = 1, j = 2, k = 3;
		System.out.println(i + ", " + j + ", " + k);
		System.out.println("i = " + i + ", j = " + j + ", k = " + k);
	}
}
