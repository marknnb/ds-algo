class Z1 
{
	public static void main(String[] args) 
	{
		int i;
		System.out.println(i);
	}
}
