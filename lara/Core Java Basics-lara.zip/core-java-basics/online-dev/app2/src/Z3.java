class Z3 
{
	public static void main(String[] args) 
	{
		int i = 10;
		int i = 20;
		System.out.println("done");
	}
}
