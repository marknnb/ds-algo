class Z4 
{
	public static void main(String[] args) 
	{
		int i = 100;
		double i = 4.5;
		System.out.println("done");
	}
}
