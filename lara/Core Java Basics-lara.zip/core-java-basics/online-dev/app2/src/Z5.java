class Z5 
{
	public static void main(String[] args) 
	{
		int i = true;
		System.out.println("done");
	}
}
