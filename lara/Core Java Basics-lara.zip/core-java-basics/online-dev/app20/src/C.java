class C 
{
	static void test1()
	{
		System.out.println("Hello World!");
		test2();
	}
	void test2()
	{
		System.out.println("Hello World!");
	}
}
