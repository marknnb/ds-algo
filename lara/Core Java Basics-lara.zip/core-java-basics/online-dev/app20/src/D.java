class D 
{
	public void test1()
	{
		System.out.println("Hello World!");
	}

	static
	{
		test1();
	}
}
