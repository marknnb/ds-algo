class E
{
	int i;

	static
	{
		i = 20;
	}
}
