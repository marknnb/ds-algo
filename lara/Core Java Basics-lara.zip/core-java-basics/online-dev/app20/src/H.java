class H 
{
	void test()
	{
	}

	static
	{
		H h1 = new H();
		h1.test();
	}
}
