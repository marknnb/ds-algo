class I 
{
	int x;
	static void test()
	{
		I obj = new I();
		System.out.println(obj.x);
	}
}
