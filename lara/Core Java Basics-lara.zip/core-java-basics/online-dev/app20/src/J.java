class J 
{
	int x;
	
	static
	{
		J ref = new J();
		System.out.println(ref.x);
	}
}
