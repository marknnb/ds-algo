class F 
{
	void F()
	{
		System.out.println("F()");
	}
	public static void main(String[] args) 
	{
		System.out.println("main begin");
		F f1 = new F();
		System.out.println("main end");
	}
}
