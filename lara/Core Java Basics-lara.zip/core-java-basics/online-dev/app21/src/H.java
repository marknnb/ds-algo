class H 
{
	public static void main(String[] args) 
	{
		System.out.println("main begin");
		H obj = new H(90);
		System.out.println("main end");
	}
}
