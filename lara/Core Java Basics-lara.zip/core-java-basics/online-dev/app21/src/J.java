class J
{
	J(int i)
	{
		System.out.println("J(int)");
	}
	public static void main(String[] args) 
	{
		System.out.println("main begin");
		J obj = new J();
		System.out.println("main end");
	}
}
