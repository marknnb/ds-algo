class K
{
	K()
	{
		System.out.println("K()");
	}
	public static void main(String[] args) 
	{
		System.out.println("main begin");
		K obj = new K(20);
		System.out.println("main end");
	}
}
