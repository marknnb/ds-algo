class D 
{
	D(int i)
	{
		System.out.println("D(int i");
	}
	D(int j)
	{
		System.out.println("D(int j");
		System.out.println("D(int j");
		System.out.println("D(int j");
		System.out.println("D(int j");
	}
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}
