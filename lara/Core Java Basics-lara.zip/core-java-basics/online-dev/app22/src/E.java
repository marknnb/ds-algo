class E 
{
	E(int i, int j)
	{
	}

	E(int i, double j)
	{
	}
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}
