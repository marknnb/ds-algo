class J 
{
	J()
	{
		System.out.println("J()");
		this(90);
	}
	J(int i)
	{
		System.out.println("J(int)");
	}
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}
