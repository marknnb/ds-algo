class K 
{
	K()
	{
		this(90);
		System.out.println("K()");
	}
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}
