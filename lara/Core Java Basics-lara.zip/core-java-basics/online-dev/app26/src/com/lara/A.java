package com.lara;

class A 
{
	public static void main(String[] args) 
	{
		System.out.println("from com.lara.A");
	}
}
