class A
{
	private int i;
}
class N extends A
{
	public static void main(String[] args) 
	{
		N n1 = new N();
		System.out.println(n1.i);
	}
}
