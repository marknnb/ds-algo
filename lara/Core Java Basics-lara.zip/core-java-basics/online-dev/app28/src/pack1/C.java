package pack1;
class C extends A
{
	public static void main(String[] args) 
	{
		C c1 = new C();
		System.out.println(c1.x);
		System.out.println(c1.y);
		System.out.println(c1.z);
	}
}
