package pack2;
class E
{
	public static void main(String[] args) 
	{
		pack1.A a1 = new pack1.A();
		//System.out.println(a1.x);
		//System.out.println(a1.y);
		System.out.println(a1.z);
	}
}
