package pack2;
public class G extends F
{
	public static void main(String[] args) 
	{
		G g1 = new G();
		System.out.println(g1.y);
		System.out.println(g1.z);
	}
}
