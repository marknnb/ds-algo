package pack2;
class H
{
	public static void main(String[] args) 
	{
		F f1 = new F();
		//System.out.println(f1.y);
		System.out.println(f1.z);
		G g1 = new G();
		//System.out.println(g1.y);
		System.out.println(g1.z);
	}
}
