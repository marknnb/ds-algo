package pack3;
//import pack2.G;
import pack2.*;
public class I extends G
{
	public static void main(String[] args) 
	{
		I obj = new I();
		System.out.println(obj.y);
		System.out.println(obj.z);
	}
}
