abstract class A 
{
	void test1()
	{
		
	}

	abstract void test2();
}
