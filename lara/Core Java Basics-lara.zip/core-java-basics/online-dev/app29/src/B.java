abstract class A
{
	abstract void test1();
	abstract void test2();
	abstract void test3();
	abstract void test4();
}
class B 
{
	public static void main(String[] args) 
	{
		//A a1 = new A();
		A a1 = null;
		System.out.println("done");
	}
}
