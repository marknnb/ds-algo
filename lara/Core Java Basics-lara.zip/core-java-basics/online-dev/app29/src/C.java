abstract class A
{
	abstract int test1();
}
class C 
{
	A a1;
	C(A a1)
	{

	}
	static void method1(A a1)
	{
	}

	static A method2()
	{
		return null;
	}
	public static void main(String[] args) 
	{
		System.out.println("done");
	}
}
