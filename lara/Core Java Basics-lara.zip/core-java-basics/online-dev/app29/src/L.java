abstract class L 
{
	abstract L();
}
