abstract class M 
{
	abstract int i;
}
