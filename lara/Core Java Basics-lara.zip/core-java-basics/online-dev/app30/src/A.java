abstract class A 
{
	abstract void test1();
	abstract void test2();
	abstract void test3();
	abstract void test4();
}
