interface B
{
}