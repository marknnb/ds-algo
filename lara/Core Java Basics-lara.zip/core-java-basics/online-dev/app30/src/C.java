interface C
{
	void test()
	{
	}

	C()
	{
	}


	{
	}

	static
	{
	}
}