interface A
{
}
class D 
{
	public static void main(String[] args) 
	{
		//A a1 = new A();
		A a2 = null;
		System.out.println("Hello World!");
	}
}
