interface A
{
	void test1();
	void test2();
}
class G implements A 
{
	public void test1()
	{
	}
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}
