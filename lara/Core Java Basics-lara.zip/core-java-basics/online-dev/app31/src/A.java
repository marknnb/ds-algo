class A 
{
	void test()
	{
	}
	void test(int i)
	{
	}
	int test(double i)
	{
		return 20;
	}
	void test(int i, int j)
	{
	}
	static void test(double i, int j)
	{
	}
}
