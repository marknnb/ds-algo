class M1 
{
	public static void main(String[] args) 
	{
		int[] elements = {10, 40, 15, 40, 25, 5};   // 6 elements
		               //  0   1   2  3   4   5
		System.out.println(elements[0]);
		System.out.println(elements[1]);
		System.out.println(elements[2]);
		System.out.println(elements[3]);
		System.out.println(elements[4]);
		System.out.println(elements[5]);
	}
}
