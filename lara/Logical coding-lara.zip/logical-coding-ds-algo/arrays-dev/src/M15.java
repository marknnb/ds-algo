class M15
{
	public static void main(String[] args) 
	{
		int[] elements = {10, 40, 15, 40, 25, 5};   // 6 elements
		               //  0   1   2  3   4   5
		System.out.println(elements[(elements.length / 2) - 1]);
		System.out.println(elements[(elements.length / 2)]);	
	}
}
