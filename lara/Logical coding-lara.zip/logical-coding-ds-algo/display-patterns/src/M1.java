/*
	
	11111
	11111
	11111
	11111
	11111

*/



class M1 
{
	public static void main(String[] args) 
	{
		for(int rows = 1; rows <= 5; rows++)
		{
			for(int cols = 1; cols <= 5; cols ++)
			{
				System.out.print(1);
			}
			System.out.println();
		}
	}
}






