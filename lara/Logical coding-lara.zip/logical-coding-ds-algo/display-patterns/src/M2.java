/*

	000000
	000000
	000000
	000000

*/




class M2 
{
	public static void main(String[] args) 
	{
		for(int rows = 1; rows <= 4; rows ++)
		{
			for(int cols = 1; cols <= 6; cols ++)
			{
				System.out.print(0);
			}
			System.out.println();
		}
	}
}
