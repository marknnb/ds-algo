/*

	****
	****
	****
	****
	****
	****

*/

class M3 
{
	public static void main(String[] args) 
	{
		for(int rows = 1; rows <= 6; rows++)
		{
			for(int cols = 1; cols <= 4; cols ++)
			{
				System.out.print('*');
			}
			System.out.println();
		}
	}
}
