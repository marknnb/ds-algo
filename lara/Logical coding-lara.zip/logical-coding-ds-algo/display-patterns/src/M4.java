
/*

	1 1 1 1 1 1 1 1
	1 1 1 1 1 1 1 1
	1 1 1 1 1 1 1 1
	1 1 1 1 1 1 1 1
*/


class M4 
{
	public static void main(String[] args) 
	{
		for(int rows = 1; rows <= 4; rows ++)
		{
			for(int cols = 1; cols <= 8; cols ++)
			{
				System.out.print("1 ");
			}
			System.out.println();
		}
	}
}
