
/*

	0 0 0 0
	0 0 0 0
	0 0 0 0
	0 0 0 0
	0 0 0 0
	0 0 0 0
	0 0 0 0
	0 0 0 0



*/


class M5
{
	public static void main(String[] args) 
	{
		for(int rows = 1; rows <= 8; rows++)
		{
			for(int cols = 1; cols <= 4; cols ++)
			{
				System.out.print("0 ");
			}
			System.out.println();
		}
	}
}






