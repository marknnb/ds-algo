/*
	123456
	123456
	123456
	123456
	123456
	123456
*/

class M6 
{
	public static void main(String[] args) 
	{
		for(int rows = 1; rows <=6; rows++)
		{
			for(int cols = 1; cols <= 6; cols++)
			{
				System.out.print(cols);
			}
			System.out.println();
		}
	}
}
