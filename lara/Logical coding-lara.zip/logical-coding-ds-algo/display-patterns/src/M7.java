


/*

	456789
	456789
	456789
	456789
	456789
	456789
	456789
	456789
*/



class M7 
{
	public static void main(String[] args) 
	{
		for(int rows = 1; rows <= 8; rows++)
		{
			for(int cols = 4; cols <= 9; cols++)
			{
				System.out.print(cols);
			}
			System.out.println();
		}
	}
}







