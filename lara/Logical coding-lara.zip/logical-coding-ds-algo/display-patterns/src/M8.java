/*
	987654321
	987654321
	987654321
	987654321
	987654321
	987654321
	987654321
	987654321
*/






class M8
{
	public static void main(String[] args) 
	{
		for(int rows = 1; rows <= 8; rows++)
		{
			for(int cols = 9; cols >= 1; cols --)
			{
				System.out.print(cols);
			}
			System.out.println();
		}
	}
}
