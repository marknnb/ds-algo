
class M1 
{
	public static void main(String[] args) 
	{
		String s1 = "hello";
		//           01234
		int i = s1.length();
		System.out.println(s1);
		System.out.println(i);
	}
}
