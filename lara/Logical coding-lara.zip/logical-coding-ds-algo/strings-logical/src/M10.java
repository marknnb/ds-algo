
class M10
{
	public static void main(String[] args) 
	{
		String s1 = "hello";
		//           01234
		System.out.println(s1);
		char[] chars = s1.toCharArray();
		System.out.println(java.util.Arrays.toString(chars));
	}
}
