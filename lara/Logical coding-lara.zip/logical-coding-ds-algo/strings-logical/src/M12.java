class M12 
{
	public static void main(String[] args) 
	{
		String s1 = "hello";
		//           01234
		int i = s1.indexOf('e');
		System.out.println(i);
		int j = s1.indexOf('l');
		System.out.println(j);
	}
}
