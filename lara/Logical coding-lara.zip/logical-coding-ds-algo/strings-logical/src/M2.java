
class M2
{
	public static void main(String[] args) 
	{
		String s1 = "hello";
		//           01234
		char c1 = s1.charAt(3);
		char c2 = s1.charAt(1);
		System.out.println(s1);
		System.out.println(c1);
		System.out.println(c2);
	}
}
