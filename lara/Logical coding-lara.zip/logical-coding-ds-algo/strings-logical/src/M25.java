class M25
{
	public static void main(String[] args) 
	{
		String s1 = "core java is base to all java and JEE in a java echo system";
		//           0123
		int i = s1.lastIndexOf("J2EE");
		System.out.println(i);
	}
}
