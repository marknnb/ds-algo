class S 
{
	void test()
	{
		System.out.println("test");
	}
	public static void main(String[] args) 
	{
		S s1 = new S();
		s1.test();
		System.out.println("main");
	}
}
