function validateMyForm()
{
	var myForm = document.forms[0];
	var firstName = myForm.firstName;
	if(firstName.value.length == 0)
	{
		alert("Please enter firstName");
		firstName.focus();
		return false;
	}
	var lastName = myForm.lastName;
	if(lastName.value.length == 0)
	{
		alert("Please enter Last name");
		lastName.focus();
		return false;
	}
	return true;
}