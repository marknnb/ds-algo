package com.lara;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Servlet1
 */
public class Servlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Servlet1() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		String s1 = request.getParameter("firstName");
		String s2 = request.getParameter("lastName");
		out.println("first Name:" + s1);
		out.println("<br/>first Name:" + s1);
		String fullName = s1 + " " + s2;
		request.setAttribute("results", fullName);
		System.out.println("Servlet1 begin (sop)");
		out.println("<br/>servlet1 begin");
		//RequestDispatcher rd = request.getRequestDispatcher("Servlet2");
		//RequestDispatcher rd = getServletContext().getRequestDispatcher("/Servlet2");
		//rd.forward(request, response);
		//rd.include(request, response);
		
		response.sendRedirect("Servlet2");
		
		System.out.println("Servlet1 end (sop)");
		out.println("<br/>servlet1 end");
	}
}











