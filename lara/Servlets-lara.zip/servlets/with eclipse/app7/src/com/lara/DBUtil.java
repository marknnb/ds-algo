package com.lara;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtil {
	private static final String DRIVER_CLASS = "oracle.jdbc.driver.OracleDriver";
	private static final String URL = "jdbc:oracle:thin:@localhost:1521:orcl";
	private static final String USERNAME = "system";
	private static final String PASSWORD = "Great123";
	private static Connection con;
	
	static
	{
		try
		{
			Class.forName(DRIVER_CLASS);
		}
		catch(ClassNotFoundException ex)
		{
			ex.printStackTrace();
		}
		
		try
		{
			con = DriverManager.getConnection(URL, USERNAME, PASSWORD);
		}
		catch(SQLException ex)
		{
			ex.printStackTrace();
		}
	}
	
	public static Connection getConnection()
	{
		return con;
	}
}
