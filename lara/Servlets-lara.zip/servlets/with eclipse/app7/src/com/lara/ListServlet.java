package com.lara;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ListServlet
 */
public class ListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ListServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
					throws ServletException, IOException {
		
		Connection con = DBUtil.getConnection();
		String sql = "select * from person";
		PrintWriter out = response.getWriter();
		try(Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sql))
		{
			String id;
			while(rs.next()) {
				id = rs.getString("id");
				out.println("<a href='ReadServlet?id=" + id + "'>" + id + "</a>&nbsp;&nbsp;&nbsp;");
				out.println(rs.getString("first_name") + "&nbsp;&nbsp;&nbsp;");
				out.println(rs.getString("last_name") + "<br/>");
			}
		}
		catch(SQLException ex)
		{
			ex.printStackTrace();
		}
		out.println("<a href='create.html'>CREATE NEW PERSON</a><br/>");
		out.println("<a href='index.html'>HOME</a><br/>");
	}

}












