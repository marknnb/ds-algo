package com.lara;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class DeletePerson
 */
public class DeletePerson extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DeletePerson() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id = request.getParameter("id");	
		StringBuffer sql = new StringBuffer();
		sql.append("delete from person where id = " + id);		
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");		
		int status = 0;
		try(Connection con = Util.getConnection();
			Statement stmt = con.createStatement()){
			status = stmt.executeUpdate(sql.toString());
		}
		catch(SQLException ex) {
			ex.printStackTrace();
		}
		if(status == 1) {
			out.println("row deleted successfully.");
		}
		else {
			out.println("some error while deleting");
		}
		out.println("<br/> <a href='index.html'>Home</a>");
	}

}









