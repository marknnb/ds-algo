package com.lara;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ReadPersons
 */
public class ReadPersons extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ReadPersons() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		StringBuffer sql = new StringBuffer();
		sql.append("select id, first_name, last_name, age from person");		
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		
		try(Connection con = Util.getConnection();
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sql.toString())){
			out.println("<table border='1'>");
			out.println("<tr>");
			out.println("<th>ID</th>");
			out.println("<th>First Name</th>");
			out.println("<th>Last Name</th>");
			out.println("<th>Age</th>");
			out.println("<th>Read</th>");
			out.println("<th>Update</th>");
			out.println("<th>Delete</th>");
			out.println("</tr>");
			String id;
			while(rs.next()) {
				id = rs.getString("id");
				out.println("<tr>");
				out.println("<td>" +  id + "</td>");
				out.println("<td>" +  rs.getString("first_name") + "</td>");
				out.println("<td>" +  rs.getString("last_name") + "</td>");				
				out.println("<td>" +  rs.getString("age") + "</td>");				
				out.println("<td><a href='readPerson?id=" + id + "'> Read " + id + "</a></td>");
				out.println("<td><a href='updatePerson?id=" + id + "'> Update " + id + "</a></td>");
				out.println("<td><a href='deletePerson?id=" + id + "'> Delete " + id + "</a></td>");
				out.println("</tr>");
			}
			out.println("</table>");
			out.println("<a href='index.html'>Home</a>");
		}
		catch(SQLException ex) {
			ex.printStackTrace();
		}
	}
}












