package com.lara;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class SaveUpdates
 */
public class SaveUpdates extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SaveUpdates() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id = request.getParameter("id");
		String firstName = request.getParameter("firstName");
		String lastName = request.getParameter("lastName");
		String age = request.getParameter("age");
		StringBuffer sql = new StringBuffer();
		sql.append("update person set first_name = '" + firstName + "', ");
		sql.append("last_name = '" + lastName + "', ");
		sql.append("age = " + age + " ");
		sql.append("where id = " + id);
		int status = 0;
		try(Connection con = Util.getConnection();
			Statement stmt = con.createStatement()){
			status = stmt.executeUpdate(sql.toString());
		}
		catch(SQLException ex) {
			ex.printStackTrace();
		}
		
		PrintWriter out = response.getWriter();
		if(status == 1) {
			out.println(firstName + " updated successfully.");
		}
		else {
			out.println("error while updating");
		}
		out.println("<br/> <a href='index.html'>Home</a>");
		response.setContentType("text/html");	
	}
}














