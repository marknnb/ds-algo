package com.lara;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class UpdatePerson
 */
public class UpdatePerson extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdatePerson() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id = request.getParameter("id");	
		StringBuffer sql = new StringBuffer();
		sql.append("select id, first_name, last_name, age from person where id = " + id);		
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");	
		out.println("<form action='saveUpdates' method='post'>");
		try(Connection con = Util.getConnection();
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sql.toString())){
			if(rs.next()) {
				out.println("ID: <input type='text' name='id' value='" + id + "' readonly/> <br/>");
				out.println("First Name: <input type='text' name='firstName' value='" + rs.getString("first_name") + "'/><br/>");
				out.println("Last Name: <input type='text' name='lastName' value='" + rs.getString("last_name") + "'/><br/>");
				out.println("Age: <input type='text' name='age' value='" + rs.getString("age") + "'/><br/>");
				out.println("<input type='submit' value='submit'/>");
			}
		}
		catch(SQLException ex) {
			ex.printStackTrace();
		}
		out.println("</form>");
		out.println("<br/> <a href='index.html'>Home</a>");
	}
}













