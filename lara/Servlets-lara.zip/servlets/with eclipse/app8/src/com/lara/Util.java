package com.lara;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Util {
	public static Connection getConnection() throws SQLException{
		String driverClass = "oracle.jdbc.driver.OracleDriver";
		String url = "jdbc:oracle:thin:@localhost:1521:orcl";
		String username = "system";
		String password = "Great123";
		try {
			Class.forName(driverClass);
		}
		catch(ClassNotFoundException  ex) {
			ex.printStackTrace();
		}
		Connection con = DriverManager.getConnection(url, username, password);
		return con;
	}
}
