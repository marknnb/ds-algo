package com.lara;


import javax.servlet.*;
import javax.servlet.http.*;

import java.io.*;

public class Servlet2 extends HttpServlet 
{
	public void service(HttpServletRequest request, HttpServletResponse response)
		throws ServletException, IOException
	{
		PrintWriter out = response.getWriter();
		String s1 = request.getParameter("param1");
		String s2 = request.getParameter("firstName");
		out.println("Parameter1:" + s1);
		out.println("First Name:" + s2);
		out.println("Hello World! from a Servlet2 through out");
		System.out.println("Hello World! from a Servlet2 through SOP");
	}
}
